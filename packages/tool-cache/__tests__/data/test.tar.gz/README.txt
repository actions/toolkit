Recreate using "tar --create --gzip --format pax --file test.tar.gz *" otherwise the BSD tar on Windows will not preserve UTF filenames correctly
